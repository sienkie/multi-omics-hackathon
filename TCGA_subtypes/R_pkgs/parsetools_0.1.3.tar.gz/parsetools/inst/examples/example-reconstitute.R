
pd_reconstitute(roots[1], pd)
