# parsetools 0.1.3

* Updated individual file license boiler-plates to reflect the GPL-2 which is listed in the DESCRIPTION file.


# parsetools 0.1.2

* Functionality updated to reflect change in parser introduced in revision 77722 of base R.

# parsetools 0.1.1

*  Bug fix for bug introduced in R-devel.
* Internal fixes and enhancements.

# parsetools 0.1

* Added a `NEWS.md` file to track changes to the package.
* Initial Release.
