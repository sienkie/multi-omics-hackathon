# purrrogress 0.1.1

* Bug fixes.
* Examples updated.

# purrrogress 0.1.0

* Initial Release
* Includes support for windows progress bars.
* Added support for flexible text `R6_box_progress` bars.
* Added a `NEWS.md` file to track changes to the package.
* Added examples.