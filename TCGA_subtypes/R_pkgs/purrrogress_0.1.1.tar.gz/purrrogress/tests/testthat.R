library(testthat)
library(purrrogress)

test_check("purrrogress")
