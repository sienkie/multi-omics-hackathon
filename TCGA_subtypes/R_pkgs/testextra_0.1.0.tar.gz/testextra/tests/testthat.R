# This file was created by `documentation::extract_tests` on 2018-11-12 16:19:15.
# Once present, this file will not be overwritten and changes will persist.
# To recreate the default version of this file delete and rerun `extract_tests`.
library(testthat)
test_check("testextra")
